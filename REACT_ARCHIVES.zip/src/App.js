import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes, useNavigate } from 'react-router-dom';
import SearchBar from './components/SearchBar';
import MovieList from './components/MovieList';
import MovieDetail from './components/MovieDetail';
import { searchMovies } from './services/tmdb';
import './App.css'; // Importe o arquivo de estilos

const App = () => {
  const [movies, setMovies] = useState([]);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const handleSearch = async (query) => {
    if (!query.trim()) {
      setError('Please enter a movie title.');
      setMovies([]);
      return;
    }

    setError(null);
    try {
      const results = await searchMovies(query);
      if (results.length === 0) {
        setError('No movies found. Please try another search.');
      }
      setMovies(results);
      navigate('/');
    } catch (error) {
      setError('An error occurred while searching for movies. Please try again later.');
      setMovies([]);
    }
  };

  return (
    <div className="container">
      <h1>Movie Search</h1>
      <div className="search-bar">
        <SearchBar onSearch={handleSearch} />
      </div>
      {error && <p className="error-message">{error}</p>}
      <Routes>
        <Route path="/" element={<MovieList movies={movies} />} />
        <Route path="/movie/:movieId" element={<MovieDetail />} />
      </Routes>
    </div>
  );
};

export default () => (
  <Router>
    <App />
  </Router>
);